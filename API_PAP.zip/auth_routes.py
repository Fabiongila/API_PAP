from flask import Blueprint, request, jsonify
from models import db, User, Log
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity, get_jwt

auth_bp  = Blueprint("auth", __name__, url_prefix="/api")
blacklist = set()

def add_log(acao, detalhe, utilizador="Sistema"):
    try:
        db.session.add(Log(acao=acao, detalhe=detalhe, utilizador=utilizador))
        db.session.commit()
    except Exception:
        db.session.rollback()

# POST /api/register
@auth_bp.route("/register", methods=["POST"])
def register():
    d = request.get_json(silent=True) or {}
    nome  = (d.get("nome") or "").strip()
    email = (d.get("email") or "").strip().lower()
    pw    = d.get("password") or ""
    if not nome or not email or not pw:
        return jsonify({"erro": "Nome, email e senha são obrigatórios"}), 400
    if len(pw) < 6:
        return jsonify({"erro": "A senha deve ter pelo menos 6 caracteres"}), 400
    if User.query.filter_by(email=email).first():
        return jsonify({"erro": "Email já registado"}), 409
    u = User(nome=nome, email=email, role="agricultor")
    u.set_password(pw)
    db.session.add(u)
    db.session.commit()
    add_log("Nova conta registada", f'"{nome}" registou-se', nome)
    return jsonify({"msg": "Conta criada com sucesso"}), 201

# POST /api/login
@auth_bp.route("/login", methods=["POST"])
def login():
    d = request.get_json(silent=True) or {}
    email = (d.get("email") or "").strip().lower()
    pw    = d.get("password") or ""
    if not email or not pw:
        return jsonify({"erro": "Email e senha são obrigatórios"}), 400
    u = User.query.filter_by(email=email).first()
    if not u or not u.check_password(pw):
        add_log("Tentativa de acesso falhada", f"Password incorreta para {email}")
        return jsonify({"erro": "Credenciais inválidas"}), 401
    if not u.is_active:
        return jsonify({"erro": "Conta desactivada. Contacte o administrador."}), 403
    token = create_access_token(identity=str(u.id))
    add_log("Acesso ao sistema", f"Login bem sucedido via browser", u.nome)
    return jsonify({"token": token, "user": {"id": u.id, "nome": u.nome, "email": u.email, "role": u.role}}), 200

# POST /api/logout
@auth_bp.route("/logout", methods=["POST"])
@jwt_required()
def logout():
    blacklist.add(get_jwt()["jti"])
    return jsonify({"msg": "Logout feito com sucesso"}), 200

# GET /api/profile
@auth_bp.route("/profile", methods=["GET"])
@jwt_required()
def get_profile():
    u = User.query.get(int(get_jwt_identity()))
    if not u: return jsonify({"erro": "Utilizador não encontrado"}), 404
    return jsonify(u.to_dict()), 200

# PUT /api/profile
@auth_bp.route("/profile", methods=["PUT"])
@jwt_required()
def update_profile():
    u = User.query.get(int(get_jwt_identity()))
    if not u: return jsonify({"erro": "Utilizador não encontrado"}), 404
    d = request.get_json(silent=True) or {}
    if "nome"     in d and d["nome"].strip(): u.nome = d["nome"].strip()
    if "password" in d and d["password"]:
        if len(d["password"]) < 6:
            return jsonify({"erro": "A senha deve ter pelo menos 6 caracteres"}), 400
        u.set_password(d["password"])
    db.session.commit()
    add_log("Perfil actualizado", f'"{u.nome}" actualizou o seu perfil', u.nome)
    return jsonify(u.to_dict()), 200

# DELETE /api/delete-account
@auth_bp.route("/delete-account", methods=["DELETE"])
@jwt_required()
def delete_account():
    u = User.query.get(int(get_jwt_identity()))
    if not u: return jsonify({"erro": "Utilizador não encontrado"}), 404
    nome = u.nome
    db.session.delete(u)
    db.session.commit()
    add_log("Conta eliminada", f'"{nome}" eliminou a sua conta', nome)
    return jsonify({"msg": "Conta deletada com sucesso"}), 200
