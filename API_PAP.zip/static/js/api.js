/**
 * AgroCaua API Client — v2
 */
const API_BASE = window.location.origin;

function getToken()        { return localStorage.getItem('agrocaua_token'); }
function saveToken(t)      { localStorage.setItem('agrocaua_token', t); }
function clearToken()      { localStorage.removeItem('agrocaua_token'); localStorage.removeItem('agrocaua_user'); }

async function authenticatedFetch(endpoint, options = {}) {
    const token = getToken();
    const headers = { 'Content-Type': 'application/json', ...options.headers };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    try {
        const response = await fetch(`${API_BASE}${endpoint}`, { ...options, headers });
        if (response.status === 401) { clearToken(); window.location.href = '/login'; throw new Error('Authentication required'); }
        return response;
    } catch (error) { console.error('API request failed:', error); throw error; }
}

const API = {
    // ── Auth ──
    login:         (email, password) => fetch(`${API_BASE}/api/login`,    { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email, password}) }),
    register:      (nome, email, password) => fetch(`${API_BASE}/api/register`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({nome, email, password}) }),
    logout:        ()                => authenticatedFetch('/api/logout',  { method:'POST' }),
    deleteAccount: ()                => authenticatedFetch('/api/delete-account', { method:'DELETE' }),

    // ── Perfil ──
    getProfile:    ()                => authenticatedFetch('/api/profile'),
    updateProfile: (data)            => authenticatedFetch('/api/profile', { method:'PUT', body: JSON.stringify(data) }),

    // ── Sensor Data ──
    getAllData:     ()                => authenticatedFetch('/api/dados_sensores'),
    getGPS:        ()                => authenticatedFetch('/api/gps'),
    getBME280:     ()                => authenticatedFetch('/api/bme280'),
    getSolo:       ()                => authenticatedFetch('/api/solo'),
    getVibracao:   ()                => authenticatedFetch('/api/vibracao'),
    getVisao:      ()                => authenticatedFetch('/api/visao'),
    getAlertas:    ()                => authenticatedFetch('/api/alertas'),

    // ── Admin ──
    admin: {
        getStats:        ()           => authenticatedFetch('/api/admin/stats'),
        // Utilizadores
        getUsers:        ()           => authenticatedFetch('/api/admin/users'),
        createUser:      (d)          => authenticatedFetch('/api/admin/users', { method:'POST', body: JSON.stringify(d) }),
        updateUser:      (id, d)      => authenticatedFetch(`/api/admin/users/${id}`, { method:'PUT', body: JSON.stringify(d) }),
        deleteUser:      (id)         => authenticatedFetch(`/api/admin/users/${id}`, { method:'DELETE' }),
        // Fazendas
        getFazendas:     ()           => authenticatedFetch('/api/admin/fazendas'),
        createFazenda:   (d)          => authenticatedFetch('/api/admin/fazendas', { method:'POST', body: JSON.stringify(d) }),
        updateFazenda:   (id, d)      => authenticatedFetch(`/api/admin/fazendas/${id}`, { method:'PUT', body: JSON.stringify(d) }),
        deleteFazenda:   (id)         => authenticatedFetch(`/api/admin/fazendas/${id}`, { method:'DELETE' }),
        // Sensores
        getSensores:     ()           => authenticatedFetch('/api/admin/sensores'),
        createSensor:    (d)          => authenticatedFetch('/api/admin/sensores', { method:'POST', body: JSON.stringify(d) }),
        updateSensor:    (id, d)      => authenticatedFetch(`/api/admin/sensores/${id}`, { method:'PUT', body: JSON.stringify(d) }),
        deleteSensor:    (id)         => authenticatedFetch(`/api/admin/sensores/${id}`, { method:'DELETE' }),
        // Logs
        getLogs:         ()           => authenticatedFetch('/api/admin/logs'),
    }
};
