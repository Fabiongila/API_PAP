from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import db, User, Fazenda, Sensor, Log, DadosIoT
from datetime import datetime

admin_bp = Blueprint("admin", __name__, url_prefix="/api/admin")

# ── helpers ─────────────────────────────────────────
def current_user():
    uid = int(get_jwt_identity())
    return User.query.get(uid)

def require_admin(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(*args, **kwargs):
        u = current_user()
        if not u or u.role not in ("superadmin", "admin"):
            return jsonify({"erro": "Acesso negado"}), 403
        return fn(*args, **kwargs)
    return wrapper

def add_log(acao, detalhe, utilizador="Sistema"):
    try:
        db.session.add(Log(acao=acao, detalhe=detalhe, utilizador=utilizador))
        db.session.commit()
    except Exception:
        db.session.rollback()

# ═══════════════════════════════════════════════════
# UTILIZADORES
# ═══════════════════════════════════════════════════
@admin_bp.route("/users", methods=["GET"])
@jwt_required()
@require_admin
def list_users():
    users = User.query.order_by(User.created_at.desc()).all()
    return jsonify([u.to_dict() for u in users]), 200

@admin_bp.route("/users", methods=["POST"])
@jwt_required()
@require_admin
def create_user():
    d = request.get_json(silent=True) or {}
    nome  = (d.get("nome") or "").strip()
    email = (d.get("email") or "").strip().lower()
    pw    = d.get("password") or ""
    role  = d.get("role", "agricultor")

    if not nome or not email or not pw:
        return jsonify({"erro": "Nome, email e senha são obrigatórios"}), 400
    if User.query.filter_by(email=email).first():
        return jsonify({"erro": "Email já registado"}), 409

    u = User(nome=nome, email=email, role=role)
    u.set_password(pw)
    db.session.add(u)
    db.session.commit()
    me = current_user()
    add_log("Novo utilizador criado", f'"{nome}" adicionado com papel {role}', me.nome if me else "Admin")
    return jsonify(u.to_dict()), 201

@admin_bp.route("/users/<int:uid>", methods=["PUT"])
@jwt_required()
@require_admin
def update_user(uid):
    u = User.query.get_or_404(uid)
    d = request.get_json(silent=True) or {}
    if "nome"      in d: u.nome      = d["nome"].strip()
    if "role"      in d: u.role      = d["role"]
    if "is_active" in d: u.is_active = bool(d["is_active"])
    if "password"  in d and d["password"]: u.set_password(d["password"])
    db.session.commit()
    me = current_user()
    add_log("Utilizador editado", f'"{u.nome}" actualizado', me.nome if me else "Admin")
    return jsonify(u.to_dict()), 200

@admin_bp.route("/users/<int:uid>", methods=["DELETE"])
@jwt_required()
@require_admin
def delete_user(uid):
    u = User.query.get_or_404(uid)
    nome = u.nome
    db.session.delete(u)
    db.session.commit()
    me = current_user()
    add_log("Utilizador removido", f'"{nome}" eliminado', me.nome if me else "Admin")
    return jsonify({"msg": "Utilizador removido"}), 200

# ═══════════════════════════════════════════════════
# FAZENDAS
# ═══════════════════════════════════════════════════
@admin_bp.route("/fazendas", methods=["GET"])
@jwt_required()
@require_admin
def list_fazendas():
    fazendas = Fazenda.query.order_by(Fazenda.created_at.desc()).all()
    result = []
    for f in fazendas:
        d = f.to_dict()
        d["num_sensores"] = Sensor.query.filter_by(fazenda_id=f.id).count()
        result.append(d)
    return jsonify(result), 200

@admin_bp.route("/fazendas", methods=["POST"])
@jwt_required()
@require_admin
def create_fazenda():
    d = request.get_json(silent=True) or {}
    nome = (d.get("nome") or "").strip()
    if not nome:
        return jsonify({"erro": "Nome da fazenda é obrigatório"}), 400
    f = Fazenda(
        nome=nome,
        proprietario=d.get("proprietario", ""),
        localizacao=d.get("localizacao", ""),
        hectares=d.get("hectares"),
        cultura=d.get("cultura", ""),
        status=d.get("status", "active")
    )
    db.session.add(f)
    db.session.commit()
    me = current_user()
    add_log("Nova fazenda cadastrada", f'"{nome}" adicionada', me.nome if me else "Admin")
    return jsonify(f.to_dict()), 201

@admin_bp.route("/fazendas/<int:fid>", methods=["PUT"])
@jwt_required()
@require_admin
def update_fazenda(fid):
    f = Fazenda.query.get_or_404(fid)
    d = request.get_json(silent=True) or {}
    for field in ("nome","proprietario","localizacao","hectares","cultura","status"):
        if field in d: setattr(f, field, d[field])
    db.session.commit()
    return jsonify(f.to_dict()), 200

@admin_bp.route("/fazendas/<int:fid>", methods=["DELETE"])
@jwt_required()
@require_admin
def delete_fazenda(fid):
    f = Fazenda.query.get_or_404(fid)
    nome = f.nome
    db.session.delete(f)
    db.session.commit()
    add_log("Fazenda removida", f'"{nome}" eliminada')
    return jsonify({"msg": "Fazenda removida"}), 200

# ═══════════════════════════════════════════════════
# SENSORES
# ═══════════════════════════════════════════════════
@admin_bp.route("/sensores", methods=["GET"])
@jwt_required()
@require_admin
def list_sensores():
    sensores = Sensor.query.order_by(Sensor.created_at.desc()).all()
    result = []
    for s in sensores:
        d = s.to_dict()
        # último dado real do dispositivo
        ultimo = DadosIoT.query.filter_by(device_id=s.nome).order_by(DadosIoT.timestamp.desc()).first()
        d["ultimo_dado"] = ultimo.timestamp.isoformat() if ultimo else None
        result.append(d)
    return jsonify(result), 200

@admin_bp.route("/sensores", methods=["POST"])
@jwt_required()
@require_admin
def create_sensor():
    d = request.get_json(silent=True) or {}
    nome = (d.get("nome") or "").strip()
    if not nome:
        return jsonify({"erro": "Nome do sensor é obrigatório"}), 400
    s = Sensor(
        nome=nome,
        tipo=d.get("tipo", ""),
        fazenda_id=d.get("fazenda_id"),
        status=d.get("status", "online"),
        bateria=d.get("bateria", 100)
    )
    db.session.add(s)
    db.session.commit()
    me = current_user()
    add_log("Novo sensor cadastrado", f'"{nome}" adicionado', me.nome if me else "Admin")
    return jsonify(s.to_dict()), 201

@admin_bp.route("/sensores/<int:sid>", methods=["PUT"])
@jwt_required()
@require_admin
def update_sensor(sid):
    s = Sensor.query.get_or_404(sid)
    d = request.get_json(silent=True) or {}
    for field in ("nome","tipo","fazenda_id","status","bateria"):
        if field in d: setattr(s, field, d[field])
    db.session.commit()
    return jsonify(s.to_dict()), 200

@admin_bp.route("/sensores/<int:sid>", methods=["DELETE"])
@jwt_required()
@require_admin
def delete_sensor(sid):
    s = Sensor.query.get_or_404(sid)
    nome = s.nome
    db.session.delete(s)
    db.session.commit()
    add_log("Sensor removido", f'"{nome}" eliminado')
    return jsonify({"msg": "Sensor removido"}), 200

# ═══════════════════════════════════════════════════
# LOGS
# ═══════════════════════════════════════════════════
@admin_bp.route("/logs", methods=["GET"])
@jwt_required()
@require_admin
def list_logs():
    logs = Log.query.order_by(Log.created_at.desc()).limit(200).all()
    return jsonify([l.to_dict() for l in logs]), 200

# ═══════════════════════════════════════════════════
# DASHBOARD STATS
# ═══════════════════════════════════════════════════
@admin_bp.route("/stats", methods=["GET"])
@jwt_required()
@require_admin
def stats():
    total_users    = User.query.count()
    active_users   = User.query.filter_by(is_active=True).count()
    total_fazendas = Fazenda.query.count()
    total_sensores = Sensor.query.count()
    online_sensors = Sensor.query.filter_by(status="online").count()
    offline_sensors= Sensor.query.filter_by(status="offline").count()
    warn_sensors   = Sensor.query.filter_by(status="warn").count()
    total_readings = DadosIoT.query.count()
    last_reading   = DadosIoT.query.order_by(DadosIoT.timestamp.desc()).first()
    return jsonify({
        "users":    {"total": total_users, "active": active_users},
        "fazendas": {"total": total_fazendas},
        "sensores": {"total": total_sensores, "online": online_sensors,
                     "offline": offline_sensors, "warn": warn_sensors},
        "leituras": {"total": total_readings,
                     "ultimo": last_reading.timestamp.isoformat() if last_reading else None}
    }), 200
